#ifndef __COMPARE_H_
#define __COMPARE_H_

int compare(int prio1, int prio2);

#endif
