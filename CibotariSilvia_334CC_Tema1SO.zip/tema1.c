#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "compare.h"

#define INSERT "insert"
#define TOP "top"
#define POP "pop"
#define DIM "dim"
#define BUFFERSIZE 20000
#define ERR -12

typedef struct node {
	struct node *next;
	int priority;
	char *value;
} Node;

typedef struct queue {
	Node *head;
	int size;
} Queue;

Queue *create()
{
	Queue *q = (Queue *)malloc(sizeof(Queue));
	if (q == NULL)
		return NULL;
	q->head = NULL;
	q->size = 0;

	return q;
}

Node *top(Queue *q)
{
	return q->head;
}

void pop(Queue *q)
{
	Node *a;

	if (q->size == 0)
		return;
	else if (q->size == 1) {
		free(q->head->value);
		free(q->head);

		q->head = NULL;
		q->size = 0;
		return;
	}

	a = q->head;
	q->head = q->head->next;
	q->size -= 1;

	free(a->value);
	free(a);
}

void free_queue(Queue *q)
{
	while (q->size > 0)
		pop(q);
	if (q->size == 0) {
		free(q->head);
		free(q);
	}
}

int insert(Queue *q, char *word, int priority)
{
	int i;
	Node *temp;
	Node *node;
	char *value_updated = (char *)malloc(strlen(word) + 1);

	if (value_updated == NULL)
		return -ERR;

	node = (Node *)malloc(sizeof(Node));

	if (node == NULL) {
		free(value_updated);
		return -ERR;
	}

	node->value = (char *)malloc(strlen(word) + 1);

	if (node->value == NULL) {
		free(value_updated);
		free(node);
		return -ERR;
	}

	strcpy(value_updated, word);
	strcat(value_updated, "\0");

	strcpy(node->value, value_updated);

	node->priority = priority;

	if (q->size == 0) {
		q->head = node;
		q->size += 1;

		free(value_updated);

		return 0;
	}

	i = q->size;

	if (compare(node->priority, q->head->priority) > 0) {
		node->next = q->head;
		q->head = node;
		q->size += 1;

		free(value_updated);
		return 0;
	}

	temp = q->head;

	while (i > 0) {
		if (i == 1) {
			temp->next = node;
			q->size += 1;
		}

		if (compare(node->priority, temp->priority) < 0  &&
			compare(node->priority, temp->next->priority) > 0) {
			node->next = temp->next;
			temp->next = node;
			q->size += 1;
			break;
		}
		temp = temp->next;
		i--;
	}
	free(value_updated);
	return 0;
}

int main(int argc, char *argv[])
{
	int i;
	char *buffer = (char *)malloc(BUFFERSIZE);
	char *op;
	int prio;
	char *word;
	char *prio_char;
	Queue *queue = create();

	if (queue == NULL || buffer == NULL)
		return -ERR;

	FILE *f;

	if (argc == 1) {
		while (fgets(buffer, BUFFERSIZE, stdin)) {
			op = strtok(buffer, "\n ");
			if (op == NULL)
				continue;

			if (strcmp(op, INSERT) == 0) {
				word = strtok(NULL, "\n ");
				prio_char = strtok(NULL, "\n ");

				if (prio_char != NULL)
					prio = atoi(prio_char);
				else
					continue;

				if (strtok(NULL, "\n ") == NULL)
					if (insert(queue, word, prio))
						return -ERR;
			} else if (strcmp(op, TOP) == 0) {
				Node *node = top(queue);

				if (node != NULL && strtok(NULL, "\n ") == NULL)
					printf("%s\n", node->value);
			} else if (strcmp(op, POP) == 0) {
				if (strtok(NULL, "\n ") == NULL)
					pop(queue);
			}
		}
		free(buffer);
		free_queue(queue);
	} else {
		for (i = 1; i < argc; i++) {
			f = fopen(argv[i], "r");
			if (f == NULL)
				continue;
			while (fgets(buffer, BUFFERSIZE, f)) {
				op = strtok(buffer, "\n ");
				if (op == NULL)
					continue;

				if (strcmp(op, INSERT) == 0) {
					word = strtok(NULL, "\n ");
					prio_char = strtok(NULL, "\n ");

					if (prio_char != NULL)
						prio = atoi(prio_char);
					else
						continue;

					if (strtok(NULL, "\n ") == NULL &&
						insert(queue, word, prio))
						return -ERR;

				} else if (strcmp(op, TOP) == 0) {
					Node *node = top(queue);

					if (node != NULL &&
						strtok(NULL, "\n ") == NULL)
						printf("%s\n", node->value);
				} else if (strcmp(op, POP) == 0) {
					if (strtok(NULL, "\n ") == NULL)
						pop(queue);
				} else if (strcmp(op, DIM) == 0) {
					printf("%d\n", queue->size);
				}
			}
			fclose(f);
		}
		free(buffer);
		free_queue(queue);
	}
}
